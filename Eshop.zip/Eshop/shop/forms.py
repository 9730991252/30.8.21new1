from django import forms
from shop.models import Product

class Product_Upadate_Form(forms.ModelForm):
    class Meta:
        model=Product
        fields = ['product_name','price','sub_category','desc','image']


def save_data(request):
    if request.session.has_key('phone'):
        mobile = request.session["phone"]

        if request.method == "POST":
            form = CustomerProfileForm(request.POST)
            if form.is_valid():
                name = request.POST['name']
                address = request.POST['address']
                phone = request.POST['phone']
                usr = Customer_Detail(user=mobile, name=name, address=address, phone=phone).save()

                cart_product = Cart.objects.filter(phone=mobile)
                detail = Customer_Detail.objects.filter(user=mobile)

                for d in detail:
                    name = d.name
                    address = d.address
                    phone_no = d.phone
                # print(cart_product)

                for p in cart_product:
                    pid = p.product_id
                    # print(pid)
                    qty = p.qty
                    prc = p.price
                    pname = p.product
                    shipping = 70.0
                    total_amount = p.qty * p.price + shipping
                    # print(pname)

                    OrderDetail(mobile=mobile, product_id=pid, product_name=pname, qty=qty, price=prc,
                                total_price=total_amount).save()
                    # print(order)
                    Delivery(user=mobile, product_id=pid, product_name=pname, qty=qty, price=prc,
                             total_price=total_amount, name=name, address=address, phone_no=phone_no).save()

                    cart_product.delete()
                return render(request, 'app/emptycart.html')