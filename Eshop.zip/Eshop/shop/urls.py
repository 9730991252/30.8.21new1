
from django.contrib import admin
from django.urls import path

from shop import views

urlpatterns = [
    path('', views.index, name="ShopHome"),
    path('subcat/', views.subcat,name="sub"),
    path('product/', views.product,name="product"),
    path('reg', views.reg,name="reg"),
    path('login', views.login,name="login"),
    path('logout', views.logout,name="logout"),
    path('addtocart', views.add_to_cart,name="addtocard"),
    path('showcart', views.show_cart,name="showcart"),
    path('pluscart', views.plus_cart,name="pluscart"),
    path('minuscart', views.minus_cart,name="minuscart"),
    path('removecart', views.remove_cart,name="removecart"),
    path('paymentdone', views.payment_done,name="paymentdone"),
    path('order', views.order,name="order"),
    path('order<int:order_id>', views.order_details,name="order_details"),
    path('<int:product_id>', views.product_details, name="product_details"),
    path('subcat_details', views.subcat_details,name="subcat_details"),
    path('sellerlogin', views.sellerlogin,name="sellerlogin"),
    path('add_product', views.add_product, name="add_product"),
    path('select_category', views.select_category, name="select_category"),
    path('add_shop_category', views.add_shop_category, name="add_shop_category"),
    path('add_new_product', views.add_new_product, name="add_new_product"),
    path('my_product', views.my_product, name="my_product"),
    path('delete_product', views.delete_product, name="delete_product"),
    path('update_product<int:product_id>', views.update_product, name="update_product"),
    path('delete_order_product', views.delete_order_product, name="delete_order_product"),
    path('update_order_status', views.update_order_status, name="update_order_status"),
    path('staff_login', views.staff_login,name="staff_login"),
    path('update_product_new<int:product_id>', views.update_product_new, name="update_product_new"),
    path('add_order_product<int:order_id>', views.add_order_product,name="add_order_product"),
    path('order_success', views.order_success,name="order_success"),
    path('custmor_order<int:order_id>', views.custmor_order_details,name="custmor_order"),
    path('minus_frant', views.minus_frant,name="minus_frant"),

]
